package com.jpmc.positions_service.PositionService;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public interface PositionService {
	public List<HashMap<String, Object>> loadPosition(ArrayList<String> accountIds);
}
