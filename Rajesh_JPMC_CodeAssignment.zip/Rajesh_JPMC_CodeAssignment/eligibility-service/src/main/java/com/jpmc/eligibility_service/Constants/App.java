package com.jpmc.eligibility_service.Constants;

public class App {

	public static class Constants{
		
		public static final String ACCOUNT_ID = "accountId";
		public static final String ASSERT_ID = "assertId";
		public static final String ELIGIBILE = "eligible";
		public static final String DISCOUNT = "discount";

	}
}
