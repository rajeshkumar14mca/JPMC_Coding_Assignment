package com.jpmc.eligibility_service.Controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jpmc.eligibility_service.EligibilityService.EligibilityService;

@RestController
@RequestMapping("/eligibility")
public class EligibilityController {

	@Autowired
	private EligibilityService eligibilityService;
	
	@PostMapping("/eligibilityList")
	public List<HashMap<String, Object>> getEligibilityList(@RequestBody List<HashMap<String, Object>> accountAssertList){
		List<HashMap<String, Object>> result = null;
		try {
			result = eligibilityService.getdiscountFare((ArrayList<HashMap<String, Object>>) accountAssertList);
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			
		}
		return result;
	}

	
	
}
