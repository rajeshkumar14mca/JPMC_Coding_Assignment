package com.jpmc.fx_service.FxController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jpmc.fx_service.FxService.FxService;

@RestController
@RequestMapping("/fxCurrency")
public class FxController {
	

		@Autowired
		private FxService fxService;
		
//		@PostMapping("/currencyList")
//		public HashMap<String,String> getCurrectMultipliers(@RequestBody HashMap<String,String> currency){
//			HashMap<String,String> result = new HashMap<String,String>();
//			result.put("multiplier", fxService.getCurrectMultipliers(currency.get("currency").toString()));
//			return result;
//		}
		
		@GetMapping("/currencyList")
		public String getCurrectMultipliers(@RequestParam String currency){
			//HashMap<String,String> result = new HashMap<String,String>();
			//result.put("multiplier", fxService.getCurrectMultipliers(currency.get("currency").toString()));
			return fxService.getCurrectMultipliers(currency);
		}
}
