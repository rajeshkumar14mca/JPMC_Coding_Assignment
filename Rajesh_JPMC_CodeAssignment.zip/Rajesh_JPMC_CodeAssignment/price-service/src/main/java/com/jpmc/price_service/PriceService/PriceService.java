package com.jpmc.price_service.PriceService;

import java.util.List;
import java.util.Map;

public interface PriceService {

	public Map<String, Object> getPriceList(List<String> assertIds);

}
