package com.jpmc.positions_service.Controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jpmc.positions_service.PositionService.PositionService;


@RestController
@RequestMapping("/positions")
public class PositionController {
	private static final Logger log = LoggerFactory.getLogger(PositionController.class);

	@Autowired
	private PositionService positionService;
	
	
	@PostMapping("/positionList")
	public List getPositionList(@RequestBody ArrayList<String> accounts) {
		List result = null;
		try {
			result = positionService.loadPosition(accounts);
		}catch(Exception e) {
			log.error("Error ", e.getMessage());
		}
		return result;
	}
}
