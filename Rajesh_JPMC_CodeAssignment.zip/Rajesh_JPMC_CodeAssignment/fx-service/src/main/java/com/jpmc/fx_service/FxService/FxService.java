package com.jpmc.fx_service.FxService;

public interface FxService {
	public String getCurrectMultipliers(String currency);
}
