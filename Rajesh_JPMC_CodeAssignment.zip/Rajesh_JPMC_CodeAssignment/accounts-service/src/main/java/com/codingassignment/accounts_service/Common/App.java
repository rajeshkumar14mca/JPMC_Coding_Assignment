package com.codingassignment.accounts_service.Common;

public class App {

	public static class Constants {
		public final static String  ACCOUNT_ID = "accountsId";
		public final static String  ASSERT_ID = "assertId";
		public final static String  CURRENCY_CODE = "currencyCode";
	}
}
