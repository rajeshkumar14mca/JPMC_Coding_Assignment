package com.jpmc.eligibility_service.Bean;

import java.util.List;

public class EligibilityBean {

	private boolean eligible;
	private double discount = 0;
	private List<String> assetIDs;
	private List<String> accountIDs;
	
	
	
	public EligibilityBean(boolean eligible, double discount, List<String> assetIDs, List<String> accountIDs) {
		super();
		this.eligible = eligible;
		this.discount = discount;
		this.assetIDs = assetIDs;
		this.accountIDs = accountIDs;
	}
	
	public boolean isEligible() {
		return eligible;
	}
	public void setEligible(boolean eligible) {
		this.eligible = eligible;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public List<String> getAssetIDs() {
		return assetIDs;
	}

	public void setAssetIDs(List<String> assetIDs) {
		this.assetIDs = assetIDs;
	}

	public List<String> getAccountIDs() {
		return accountIDs;
	}

	public void setAccountIDs(List<String> accountIDs) {
		this.accountIDs = accountIDs;
	}
	
	
}
