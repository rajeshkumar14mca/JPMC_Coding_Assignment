package com.jpmc.eligibility_service.EligibilityService;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public interface EligibilityService {
	
	public List<HashMap<String, Object>> getdiscountFare(ArrayList<HashMap<String, Object>> listAccountData);
	
}
