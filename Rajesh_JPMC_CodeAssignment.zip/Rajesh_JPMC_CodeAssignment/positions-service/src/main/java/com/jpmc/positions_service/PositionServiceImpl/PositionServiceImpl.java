package com.jpmc.positions_service.PositionServiceImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jpmc.positions_service.Bean.AccountBean;
import com.jpmc.positions_service.Bean.PositionBean;
import com.jpmc.positions_service.PositionService.PositionService;

@Service
public class PositionServiceImpl implements PositionService {
	private static final Logger log = LoggerFactory.getLogger(PositionServiceImpl.class);
	
	@Override
	public List<HashMap<String, Object>> loadPosition(ArrayList<String> accountIds) {
		
		ArrayList<HashMap<String, Object>> listAccountData = null;
		List<AccountBean> accountList = null;
		List<PositionBean> positionList = null;
		List<AccountBean> currenctDataList = null;
		HashMap<String, Object> objPosition = null;
		try {
			accountList = new ArrayList<AccountBean>();
			listAccountData = new ArrayList<HashMap<String, Object>>();
			positionList =  new ArrayList<PositionBean>(); 
			
			positionList =  List.of(new PositionBean("S1", 100),new PositionBean("S3", 100),new PositionBean("S4", 100));
			log.info("positionList : "+new ObjectMapper().writeValueAsString(positionList));
			accountList.add(new AccountBean("E1", positionList));
			
			// Added additional Account E2 for testing 
//			positionList =  List.of(new PositionBean("S2", 100),new PositionBean("S5", 100));
//			log.info("positionList : "+new ObjectMapper().writeValueAsString(positionList));
//			accountList.add(new AccountBean("E2", positionList));
			
			currenctDataList = accountList.stream().filter(acc-> (accountIds.indexOf(acc.getAccountId()) > -1)).collect(Collectors.toList());
			if(currenctDataList != null && !currenctDataList.isEmpty() && currenctDataList.size()>0) {
				for(AccountBean accountObj: currenctDataList) {
					List<PositionBean> postionListObjb = accountObj.getPostionobj();
					if(postionListObjb != null && postionListObjb.size()>0) {
						for(PositionBean positionObj: postionListObjb) {
							objPosition = new HashMap<String, Object>();
							objPosition.put("accountId", accountObj.getAccountId());
							objPosition.put("assertId", positionObj.getAssertId());
							objPosition.put("quantity", positionObj.getQuantity());
							listAccountData.add(objPosition);
						}
					}
				}
			}
		
			log.info("listAccountData : "+new ObjectMapper().writeValueAsString(listAccountData));
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			accountList = null;
			positionList = null;
			currenctDataList = null;
			objPosition = null;
		}
		
		return listAccountData;
	}
}
