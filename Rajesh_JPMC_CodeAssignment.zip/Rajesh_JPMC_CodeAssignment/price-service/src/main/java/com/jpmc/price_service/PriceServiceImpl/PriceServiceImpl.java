package com.jpmc.price_service.PriceServiceImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.circuitbreaker.CircuitBreaker;
import org.springframework.cloud.client.circuitbreaker.CircuitBreakerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jpmc.price_service.Bean.PriceBean;
import com.jpmc.price_service.PriceService.PriceService;

@Service
public class PriceServiceImpl implements PriceService{

	private static final Logger log = LoggerFactory.getLogger(PriceServiceImpl.class);

	@Autowired
	private CircuitBreakerFactory circuitBreakerFactory;
	
	@Autowired
	private RestTemplate restTemplate;
	
	public Map<String, Object> getPriceList(List<String> asserIds) {// Load the PriceList with currency for the listed accounts
		List<PriceBean> priceList = null;
		Map<String, Object> price = null;
		List<PriceBean> priceListAssertId = null;
		try {
			priceList = new ArrayList<PriceBean>();
			price = new HashMap<String, Object>();
			priceListAssertId = new ArrayList<PriceBean>();
			
			priceList.add(new PriceBean.priceBuilder("S1",50.5).build());
			priceList.add(new PriceBean.priceBuilder("S2",20.2).setCurrency("JPY").build());
			priceList.add(new PriceBean.priceBuilder("S3",10.4).build());
			priceList.add(new PriceBean.priceBuilder("S4",15.5).setCurrency("USD").build());
			log.info("asserIds : "+new ObjectMapper().writeValueAsString(asserIds));
			priceListAssertId = priceList.stream().filter(pl-> asserIds.contains(pl.getAssertId().toString())).collect(Collectors.toList());
			log.info("priceListAssertId : "+new ObjectMapper().writeValueAsString(priceListAssertId));
			priceListAssertId.stream().forEach(obj ->{
				if(obj.getCurrency() != null && !obj.getCurrency().equalsIgnoreCase("USD")) {
					String value = getConvertedpriceValue(obj.getCurrency(), obj.getPrice());
					if(value != null) {
						double result = Double.parseDouble(value) * obj.getPrice();
						obj.setPrice(result);
						obj.setCurrency("USD");
					}
				}
			});

			price = priceListAssertId.stream().collect(Collectors.toMap(x->x.getAssertId(), x->x.getPrice()));
			log.info("priceList : "+new ObjectMapper().writeValueAsString(price));
	
			}catch(Exception e) {
				e.printStackTrace();
			}finally {
				priceList = null;
				priceListAssertId = null;
			}
			return price;
		}
		
	
		private String getConvertedpriceValue(String currency, double price){
			CircuitBreaker cb = circuitBreakerFactory.create("fx-service");
			return cb.run(()->this.restTemplate.getForObject("http://localhost:8056/fxCurrency/currencyList?currency="+currency, String.class), throwable->showServiceDownMessage("fx-service"));
						
		}
		public String showServiceDownMessage(String service){
			log.error(service+ " is down wait for few mins");
			return service+ " is down wait for few mins";
		}
}
