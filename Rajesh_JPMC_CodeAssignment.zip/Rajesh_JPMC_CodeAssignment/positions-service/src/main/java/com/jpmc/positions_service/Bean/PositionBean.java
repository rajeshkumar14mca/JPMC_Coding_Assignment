package com.jpmc.positions_service.Bean;

public class PositionBean {

	private String assertId;
	private long quantity;
	
	public PositionBean() {
		
	}
	public PositionBean(String assertId, long quantity) {
		this.assertId = assertId;
		this.quantity = quantity;
	}
	public String getAssertId() {
		return assertId;
	}
	
	public void setAssertId(String assertId) {
		this.assertId = assertId;
	}
	
	public long getQuantity() {
		return quantity;
	}
	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}
	
	
	
}
