package com.codingassignment.accounts_service.AccountService;

import java.util.HashMap;
import java.util.List;

public interface AccountsService {

	public List<HashMap<String,Object>> getAccountList(HashMap<String,Object> accountData);
}
