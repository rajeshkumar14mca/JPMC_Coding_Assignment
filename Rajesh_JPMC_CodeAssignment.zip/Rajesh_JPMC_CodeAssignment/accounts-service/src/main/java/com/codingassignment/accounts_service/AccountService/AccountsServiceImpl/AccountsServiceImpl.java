package com.codingassignment.accounts_service.AccountService.AccountsServiceImpl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.circuitbreaker.CircuitBreaker;
import org.springframework.cloud.client.circuitbreaker.CircuitBreakerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.codingassignment.accounts_service.AccountService.AccountsService;
import com.codingassignment.accounts_service.Common.App;
import com.fasterxml.jackson.databind.ObjectMapper;


@Service
public class AccountsServiceImpl implements AccountsService {

	 private static final Logger log = LoggerFactory.getLogger(AccountsServiceImpl.class);
	 
	 public static final String POSITIONS_SERVICE="positions-service";
	 public static final String ELIGIBILITY_SERVICE="eligibility-service";
	 public static final String FX_SERVICE="fx-service";
	 public static final String PRICE_SERVICE="price-service";

	 @Autowired
	 private RestTemplate restTemplate;
	
	 @Autowired
	 private CircuitBreakerFactory circuitBreakerFactory;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<HashMap<String, Object>> getAccountList(HashMap<String, Object> accountData) {
		// TODO Auto-generated method stub
		
		List<HashMap<String, Object>> listAccountData = null;
		ArrayList<HashMap<String, Object>> discountedData = null;
		List<String> accountIds = null;
		String currencyCode = null;
		List<HashMap<String, Object>> loadAccountList = null;
		ObjectMapper mapper = null;
		List<String> assertId = null;
		Map<String, Object> priceObj = null;
		try {
			listAccountData = new ArrayList<HashMap<String, Object>>();
			discountedData = new ArrayList<HashMap<String, Object>>();
			loadAccountList = new ArrayList<HashMap<String, Object>>();
			accountIds = new ArrayList<String>();
			mapper = new ObjectMapper();
			assertId = new ArrayList<String>();
			priceObj = new HashMap<String, Object>();
			
			currencyCode = accountData.get(App.Constants.CURRENCY_CODE).toString();
			accountIds = (List<String>) accountData.get(App.Constants.ACCOUNT_ID);
			log.info(mapper.writeValueAsString(accountIds));
			
			// Call this method to Load position list for accounts
			listAccountData = getPositionList((ArrayList<String>) accountIds);
			
			if(listAccountData != null && listAccountData.size()>0) {
				// call this method to load discount fare for the account and position
				discountedData = getEligibilityList(listAccountData);
				assertId = listAccountData.stream().map(list-> String.valueOf(list.get(App.Constants.ASSERT_ID))).collect(Collectors.toList());
				if(assertId != null && assertId.size()>0) {
					// call this to load price for eligible and non eligible account and assert id
					priceObj = getPriceList((ArrayList<String>) assertId);
				}
				if(listAccountData != null && listAccountData.size()>0 
						&& assertId != null && assertId.size()>0 
						&& priceObj != null && priceObj.size()>0) {
					// build the data for accounts with collateral and marked value
					loadAccountList = getAccountListWithcollateralValue(accountIds,currencyCode,listAccountData,priceObj,discountedData);
				}
			}
		
		}catch(Exception e){
			log.error("Error ", e.getMessage());
		}finally {
			listAccountData = null;
			discountedData = null;
			accountIds = null;
			currencyCode = null;
		}
		return loadAccountList;
	}
	
	// List the account with collateral value and market value
	@SuppressWarnings("unchecked")
	public ArrayList<HashMap<String, Object>> getAccountListWithcollateralValue(List<String> accountIds,String currencyCode,List<HashMap<String, Object>> listAccountData,Map<String, Object> priceObj, ArrayList<HashMap<String, Object>> discountedData){
		List<HashMap<String, Object>> accountListResponse = null;
		List<HashMap<String, Object>> accountList = null;
		List<Double> collateralValue = null;
		List<Double> MarketValue = null;
		Map<Object, Object> collect = null;
		ObjectMapper mapper = null;
		try {
			accountListResponse = new ArrayList<HashMap<String, Object>>();
			accountList = new ArrayList<HashMap<String, Object>>();
			collect = new HashMap<Object, Object>();
			mapper = new ObjectMapper();
			collect = listAccountData
						.stream()
						.collect(Collectors.groupingBy(x -> x.get("accountId")))
						.entrySet()
						.stream()
						.collect(Collectors.toMap(
						e -> e.getKey(),
						e -> e.getValue()));
			log.info("collect : "+mapper.writeValueAsString(collect));
			
			for(String accountId : accountIds) {
				accountList = (ArrayList<HashMap<String, Object>>) collect.get(accountId);
				collateralValue = new ArrayList<Double>();
				MarketValue = new ArrayList<Double>();
				loadCollateralAndMarketValue(accountList,collateralValue, MarketValue,discountedData, priceObj);
				accountListResponse.add(loadAccountList(accountId,collateralValue, MarketValue,currencyCode));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			accountList = null;
			collateralValue = null;
			MarketValue = null;
			collect = null;
			mapper = null;
		}
		return (ArrayList<HashMap<String, Object>>) accountListResponse;
	}

	// Collateral and Market value calculation for accounts
	public void loadCollateralAndMarketValue(List<HashMap<String, Object>> accountList,List<Double> collateralValue,List<Double> marketValue,ArrayList<HashMap<String, Object>> discountedData,Map<String, Object> priceObj)
	{
		HashMap<String, Object> discountobj = null;
		double collateral = 0;
		double market = 0;
		try {
			discountobj = new HashMap<String, Object>();
			if(accountList != null && accountList.size()>0) {
				for(HashMap<String, Object> accObj : accountList) {
					log.info("accObj : "+new ObjectMapper().writeValueAsString(accObj));
					String assertId = String.valueOf(accObj.get("assertId"));
					discountobj = discountedData.stream().filter(dis-> String.valueOf(dis.get("assertId")).equals(assertId) && Boolean.valueOf(String.valueOf(dis.get("eligible")))).findAny().orElse(null);
					log.info("discountobj : "+new ObjectMapper().writeValueAsString(discountobj));
					if(discountobj != null) {
						collateral = Double.parseDouble(String.valueOf(accObj.get("quantity"))) * Double.parseDouble(String.valueOf(priceObj.get(assertId))) * Double.parseDouble(String.valueOf(discountobj.get("discount")));
						collateralValue.add(collateral);
					}
					log.info("quantity : "+accObj.get("quantity"));
					log.info("assertId : "+priceObj.get(assertId));
					if(accObj.get("quantity") != null && priceObj.get(assertId) != null) {
						market = Double.parseDouble(String.valueOf(accObj.get("quantity"))) * Double.parseDouble(String.valueOf(priceObj.get(assertId)));
						marketValue.add(market);
					}
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			discountobj = null;
		}
	}
	
	// Load account list with the value 
	public HashMap<String,Object> loadAccountList(String accountId, List<Double> collateralValue,List<Double> MarketValue,String currencyCode){
		Map<String, Object> accountObj = null;
		Double collateral =null;
		Double market = null;
		String currencyValue = null;
		try {
			accountObj = new HashMap<String,Object>();
			
			accountObj.put("accountName",accountId);
			collateral = collateralValue.stream().mapToDouble(i-> Double.valueOf(i)).sum();
			market = MarketValue.stream().mapToDouble(i-> Double.valueOf(i)).sum();
			if(currencyCode != "USD") {
				currencyValue = getConvertedpriceValue(currencyCode);
				log.info("currencyValue "+ currencyValue);
				collateral = collateral / Double.valueOf(currencyValue);
				market = market / Double.valueOf(currencyValue);
			}
			accountObj.put("collateralValue",collateral!=null? BigDecimal.valueOf(collateral).setScale(2, RoundingMode.HALF_UP):0.00);
			accountObj.put("marketValue",market != null ?BigDecimal.valueOf(market).setScale(2, RoundingMode.HALF_UP):0.00);
			accountObj.put("currencyCode",currencyCode);
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			collateral =null;
			market = null;
			currencyValue = null;
		}
		return (HashMap<String,Object>)accountObj;
	}
	
	
	/*** Call other services to get data for this services Started ***/
	@SuppressWarnings("unchecked")
	public ArrayList<HashMap<String, Object>> getPositionList(ArrayList<String> accountIds){
		CircuitBreaker cb = circuitBreakerFactory.create(POSITIONS_SERVICE);
		return cb.run(()-> this.restTemplate.postForObject("http://localhost:8053/positions/positionList", accountIds, ArrayList.class), throwable->showCircuitBreakerMessage(POSITIONS_SERVICE));
			//Logger.info("RestTemplate positionList : "+new ObjectMapper().writeValueAsString(data));
	}
	
	@SuppressWarnings("unchecked")
	public ArrayList<HashMap<String, Object>> getEligibilityList(List<HashMap<String, Object>> listAccountData){
		CircuitBreaker cb = circuitBreakerFactory.create(ELIGIBILITY_SERVICE);
		return cb.run(()->this.restTemplate.postForObject("http://localhost:8054/eligibility/eligibilityList", listAccountData, ArrayList.class), throwable->showCircuitBreakerMessage(ELIGIBILITY_SERVICE));
	}
	
	
	@SuppressWarnings("unchecked")
	public Map<String, Object> getPriceList(ArrayList<String> assertId){
		CircuitBreaker cb = circuitBreakerFactory.create(POSITIONS_SERVICE);
		return (Map<String, Object>) cb.run(()->this.restTemplate.postForObject("http://localhost:8055/price/priceList", assertId, Map.class), throwable->showCircuitBreakerMessage(PRICE_SERVICE));
	}
	
	public String getConvertedpriceValue(String currency){
		CircuitBreaker cb = circuitBreakerFactory.create(FX_SERVICE);
		return cb.run(()-> this.restTemplate.getForObject("http://localhost:8056/fxCurrency/currencyList?currency="+currency, String.class), throwable->showServiceDownMessage(FX_SERVICE));
	}
	
	public String showServiceDownMessage(String service){
		log.error(service+ " is down wait for few mins");
		return null;
	}
	
	public ArrayList<HashMap<String, Object>> showCircuitBreakerMessage(String service){
		log.error(service+ " is down wait for few mins");
		return null;
	}
	/*** Call other services to get data for this services End ***/
}
