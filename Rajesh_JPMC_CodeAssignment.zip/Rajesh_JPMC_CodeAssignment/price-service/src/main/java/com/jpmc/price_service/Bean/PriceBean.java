package com.jpmc.price_service.Bean;

public class PriceBean {

	private String assertId;
	private double price;
	private String currency;
	
//	
//	  public priceObj(String assetId, double price, String currency) {
//		super();
//		this.assetId = assetId;
//		this.price = price;
//		this.currency = currency;
//	}
	  public PriceBean(String assertId, double price) {
			this.assertId = assertId;
			this.price = price;
		}

	public String getAssertId() {
		return assertId;
	}
	public void setAssertId(String assertId) {
		this.assertId = assertId;
		
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
		
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
		
	}
	private PriceBean(priceBuilder builder) {
		this.assertId=builder.assertId;
		this.price=builder.price;
		this.currency=builder.currency;
	}
	
	public static class priceBuilder {
		private String assertId;
		private double price;
		private String currency ="USD";
		
		public priceBuilder(String assertId, double price) {
			this.assertId = assertId;
			this.price = price;
		}
		
		
		public priceBuilder setCurrency(String currency) {
			this.currency = currency;
			return this;
		}
		
		public PriceBean build(){
			return new PriceBean(this);
		}
		
		
	}
}
