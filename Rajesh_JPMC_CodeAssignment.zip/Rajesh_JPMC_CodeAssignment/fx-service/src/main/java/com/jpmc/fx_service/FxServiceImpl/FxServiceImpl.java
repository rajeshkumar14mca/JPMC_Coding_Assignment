package com.jpmc.fx_service.FxServiceImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jpmc.fx_service.FxService.FxService;

@Service
public class FxServiceImpl implements FxService{
	
List<HashMap<String, Object>> fxService = new ArrayList<HashMap<String, Object>>();
private static final Logger log = LoggerFactory.getLogger(FxServiceImpl.class);
	
	public void loadFXService(){ // Load the multiplier amount for the currency 
		
		HashMap<String, Object> fxObj = new HashMap<String, Object>();
		fxService = new ArrayList<HashMap<String, Object>>();
		fxObj.put("currency", "JPY");
		fxObj.put("multiplier", 0.0062);
		fxService.add(fxObj);
		fxObj = new HashMap<String, Object>();
		fxObj.put("currency", "GBP");
		fxObj.put("multiplier", 1.28);
		fxService.add(fxObj);
		//return fxService;
	}
	
	@Override
	public String getCurrectMultipliers(String currency) {// Return the Currency multiplier amount for the given currency code
		String result = null;
		List<String> value = null;
		try {
			 value = new ArrayList<String>();
			if(fxService == null || fxService.size()== 0 || fxService.isEmpty()) {
				loadFXService();
			}
			
			log.info("fxService : "+new ObjectMapper().writeValueAsString(fxService));
			value = (List<String>) fxService.stream().filter(fixObj-> fixObj.get("currency").equals(currency.toString())).map(i-> i.get("multiplier").toString()).collect(Collectors.toList());
			if(value != null && value.size()>0) {
				result = value.get(0);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return result;
			
	}
}
