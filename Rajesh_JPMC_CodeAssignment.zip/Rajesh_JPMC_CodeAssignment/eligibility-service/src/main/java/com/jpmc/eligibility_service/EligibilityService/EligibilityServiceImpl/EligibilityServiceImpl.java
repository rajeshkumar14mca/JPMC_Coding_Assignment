package com.jpmc.eligibility_service.EligibilityService.EligibilityServiceImpl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jpmc.eligibility_service.Bean.EligibilityBean;
import com.jpmc.eligibility_service.Constants.App;
import com.jpmc.eligibility_service.EligibilityService.EligibilityService;

@Service
public class EligibilityServiceImpl implements EligibilityService {

	private static final Logger log = LoggerFactory.getLogger(EligibilityServiceImpl.class);
	
	@Override
	public List<HashMap<String, Object>> getdiscountFare(ArrayList<HashMap<String, Object>> listAccountData) { // AssertId and discount for eligible account
		// TODO Auto-generated method stub
		List<EligibilityBean> discountFareList = null;
		List<HashMap<String,Object>> eligiblityData = null;
		HashMap<String, Object> discountObj = null;
		try {
			eligiblityData = new ArrayList<HashMap<String,Object>>();
			discountFareList = new ArrayList<EligibilityBean>();
			
			discountFareList.add(new EligibilityBean(true, 0.9, Arrays.asList("S1","S2","S3"), Arrays.asList("E1","E2")));
			discountFareList.add(new EligibilityBean(false, 0, Arrays.asList("S4","S5"), Arrays.asList("E1","E2")));
		
			if(listAccountData != null && listAccountData.size()>0) {
		 		for(HashMap<String, Object> accountObj : listAccountData) {
		 			discountObj = new HashMap<String, Object>();
		 			EligibilityBean discount  =  discountFareList.stream()
					.filter(dis-> dis.getAccountIDs().contains(accountObj.get(App.Constants.ACCOUNT_ID)) 
							&& dis.getAssetIDs().contains(accountObj.get(App.Constants.ASSERT_ID)))
					.collect(Collectors.toList()).get(0);
		 			discountObj.put(App.Constants.ACCOUNT_ID, accountObj.get(App.Constants.ACCOUNT_ID));
		 			discountObj.put(App.Constants.ASSERT_ID, accountObj.get(App.Constants.ASSERT_ID));
		 			discountObj.put(App.Constants.ELIGIBILE, discount.isEligible());
		 			discountObj.put(App.Constants.DISCOUNT, discount.getDiscount());
		 			eligiblityData.add(discountObj);
				}
			}
	 		log.info("eligiblityData : "+new ObjectMapper().writeValueAsString(eligiblityData));
		
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			discountFareList = null;
			discountObj = null;
		}
			return eligiblityData;
	}
	
}
