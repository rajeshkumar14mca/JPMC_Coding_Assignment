package com.jpmc.positions_service.Bean;

import java.util.ArrayList;
import java.util.List;


public class AccountBean {

	private String accountId;
	private List<PositionBean> positions;
	
	public AccountBean() {
		
	}
	
	public AccountBean(String accountId, List<PositionBean> positions) {
		this.accountId = accountId;
		this.positions = positions;
	}
	public String getAccountId() {
		return accountId;
	}
	
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public void setPositions(ArrayList<PositionBean> positions) {
		this.positions = positions;
	}

	public List<PositionBean> getPostionobj() {
		return this.positions;
	}
	
}
